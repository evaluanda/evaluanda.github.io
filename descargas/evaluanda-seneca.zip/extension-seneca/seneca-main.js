/*
 * Parte de la extensión que corre en el MUNDO DE LA PÁGINA de Séneca: llama a
 * sus propias funciones (nueva(), aceptar()…) y repite las peticiones de su
 * ventana de calificar con sus mismos objetos (Hashtable, $.deparam), para que
 * todo pase por las validaciones de Séneca. Solo obedece a seneca.js:
 *   { evaSenecaMain: 'cmd', id, op, args }  →  { evaSenecaMain: 'res', id, ok, data | error }
 */
(function () {
  'use strict';

  // Si hay dos copias instaladas (la de la tienda y otra a mano), cada una solo
  // obedece a su propio seneca.js: su id sale de la URL del script en la pila.
  var YO = (/chrome-extension:\/\/([a-p]{32})\//.exec(new Error().stack || '') || [])[1] || '';

  /** Función global de Séneca por nombre (en la ventana o en su «cuerpo»). */
  function fnSeneca(nombre) {
    if (typeof window[nombre] === 'function') return window[nombre];
    try {
      var c = window.top.inferior.principal.cuerpo;
      if (c && typeof c[nombre] === 'function') return c[nombre].bind(c);
    } catch (e) { /* sin marco «cuerpo» */ }
    return null;
  }

  function valorCampo(nombre) {
    var el = document.querySelector('[name="' + nombre + '"]');
    return el ? el.value : '';
  }

  function urlModal(xNotActEva) {
    // Las celdas aún sin nota abren la ventana en modo 'new' (botón «+»), como hace Séneca.
    var b = document.querySelector('button[data-modalalumnotarea="' + xNotActEva + '"]');
    var modo = b && b.closest('.table-btn-modal.nuevo') ? 'new' : 'edit';
    var q = 'X_NOTACTEVA=' + encodeURIComponent(xNotActEva) + '&DESHABILITAR=N&MODO=' + modo +
      '&F_ENTREGA=' + encodeURIComponent(valorCampo('F_ENTREGA')) + '&L_FP=' + encodeURIComponent(valorCampo('L_FP'));
    return new URL('pasen/actividadesevaluables/MontarModalCuaderno_2023.jsp?' + q, document.baseURI).href;
  }

  /**
   * Séneca sirve sus páginas en Latin-1 sin declararlo en la cabecera: leídas
   * como UTF-8, las tildes salían como «�» y esos nombres no casaban. Se
   * prueba UTF-8 estricto y, si no lo es, Windows-1252.
   */
  function decodificar(buf) {
    try { return new TextDecoder('utf-8', { fatal: true }).decode(buf); } catch (e) { return new TextDecoder('windows-1252').decode(buf); }
  }

  /** Descarga y analiza la ventana de calificar de un alumno/a en una actividad. */
  async function leerModal(xNotActEva) {
    var r = await fetch(urlModal(xNotActEva), { credentials: 'include', cache: 'no-store' });
    if (!r.ok) throw new Error('Séneca respondió ' + r.status + ' al abrir la calificación.');
    var html = decodificar(await r.arrayBuffer());
    var doc = new DOMParser().parseFromString(html, 'text/html');
    var sel = doc.querySelector('#selecbuscadoralumnado option[selected]') ||
      doc.querySelector('#selecbuscadoralumnado option');
    // Cada nota de criterio es un <input id="X_CRIEVACOMBAS_<id>">; su código
    // («LCL.4.1.1») es el último que aparece en el texto antes del campo.
    var crits = {}, todos = [], ultimo = '';
    var tw = doc.createTreeWalker(doc.body || doc.documentElement, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    for (var n = tw.nextNode(); n; n = tw.nextNode()) {
      if (n.nodeType === 3) {
        var m = /(?:^|\s)([A-ZÑ]{2,6}(?:\.\d+){2,4})\./.exec(n.nodeValue);
        if (m) ultimo = m[1];
      } else if (n.tagName === 'INPUT' && /^X_CRIEVACOMBAS_\d+$/.test(n.id)) {
        var c = { id: n.id, valor: n.getAttribute('value') || '' };
        todos.push(c);
        if (ultimo) crits[ultimo] = c;
      }
    }
    var args = /alumnoSiguiente\('\w+',\s*'(\w*)',\s*'([^']*)',\s*'(\w*)',\s*'(\w*)',\s*'(\d*)',\s*'(\d*)',\s*'(\d*)'/.exec(html);
    var tit = '';
    doc.querySelectorAll('h1,h2,h3,h4,h5,.modal-title').forEach(function (h) {
      if (tit) return;
      var c = h.cloneNode(true);
      c.querySelectorAll('button,a,span.sr-only').forEach(function (b) { b.remove(); });
      tit = c.textContent.replace(/\s+/g, ' ').trim();
    });
    var desh = doc.querySelector('#L_DESHABILITADO');
    return {
      xNotActEva: String(xNotActEva), alumno: sel ? sel.textContent.trim() : '', titulo: tit, crits: crits, todos: todos,
      deshabilitado: !!(desh && desh.value !== 'N'),
      ctx: args ? { lDiaria: args[1], fEntrega: args[2], lFp: args[3], lLomloe: args[4],
        xGruAluProMat: args[5], xConvCentro: args[6], xActeva: args[7] } : null
    };
  }

  /**
   * Variable global de Séneca por nombre, también si está declarada con let/const
   * (no cuelga de window). undefined si no existe o la página no permite eval.
   */
  function glob(nombre) {
    try { return (0, eval)('typeof ' + nombre + ' !== "undefined" ? ' + nombre + ' : undefined'); } catch (e) { return undefined; }
  }

  /**
   * Nombre de la actividad tal como lo pinta el cuaderno: la cabecera más baja
   * (la de la actividad, no la de su categoría) de la columna en la que está
   * alguno de sus botones de calificar.
   */
  function cabeceraDe(ids) {
    for (var i = 0; i < ids.length; i++) {
      var b = document.querySelector('button[data-modalalumnotarea="' + ids[i] + '"]');
      var td = b && b.closest('td'), tabla = td && td.closest('table');
      if (!tabla) continue;
      var r = td.getBoundingClientRect(), cx = (r.left + r.right) / 2, mejor = null, top = -Infinity;
      tabla.querySelectorAll('thead th, thead td').forEach(function (th) {
        var q = th.getBoundingClientRect();
        if (q.width && q.left <= cx && cx <= q.right && q.top > top) { top = q.top; mejor = th; }
      });
      if (mejor) return mejor.textContent.replace(/\s+/g, ' ').trim();
    }
    return '';
  }

  /**
   * Actividades del cuaderno: { titulo, notActEvas[] }. Se leen de la propia
   * tabla: cada botón de calificar lleva el id de su celda (X_NOTACTEVA) y un
   * icono NOTA_<columna>_<fila>; los de la misma columna son de la misma
   * actividad, y su nombre es la cabecera de esa columna.
   */
  async function actividadesCuaderno() {
    var cols = {}, orden = [];
    document.querySelectorAll('.table-btn-modal button[data-modalalumnotarea]').forEach(function (b) {
      var ic = b.querySelector('[id^="NOTA_"]'), m = ic && /^NOTA_(\d+)_\d+$/.exec(ic.id), col = m ? m[1] : '?';
      if (!cols[col]) { cols[col] = []; orden.push(col); }
      cols[col].push(b.getAttribute('data-modalalumnotarea'));
    });
    if (!orden.length) throw new Error('El cuaderno no tiene actividades para este grupo y evaluación (¿has pulsado Refrescar?).');
    var out = [];
    for (var k = 0; k < orden.length; k++) {
      var ids = cols[orden[k]], titulo = cabeceraDe(ids);
      if (!titulo) titulo = (await leerModal(ids[0])).titulo;
      out.push({ titulo: titulo, notActEvas: ids });
    }
    return out;
  }

  /** Graba las notas {código: n} de un alumno/a en una actividad, como la ventana de calificar. */
  async function grabarNotas(xNotActEva, notas) {
    var m = await leerModal(xNotActEva);
    if (m.deshabilitado) return { modal: m, estado: 'deshabilitado' };
    if (!m.ctx) throw new Error('No se reconoce la ventana de calificar de Séneca.');
    // Como la página: se envían TODOS los campos de nota, cambiados o no.
    var cambia = false, mapCal = new window.Hashtable(), faltan = [];
    Object.keys(notas).forEach(function (cod) {
      var c = m.crits[cod];
      if (!c) faltan.push(cod); // criterio que la actividad de Séneca no tiene
      else if ( (c.valor === '' || Math.abs(parseFloat(c.valor) - notas[cod]) > 0.001)) {
        c.valor = String(notas[cod]); cambia = true;
      }
    });
    m.todos.forEach(function (c) { mapCal.put(c.id, c.valor); });
    if (!cambia) return { modal: m, estado: 'igual', faltan: faltan };
    var x = m.ctx;
    var p = 'MODO=GRABAR_NOTA_MODAL&X_NOTACTEVA=' + xNotActEva + '&L_DIARIA=' + x.lDiaria + '&L_FP=' + x.lFp +
      '&L_LOMLOE=' + x.lLomloe + '&X_GRUALUPROMAT=' + x.xGruAluProMat + '&F_ENTREGA=' + x.fEntrega +
      '&X_CONVCENTRO=' + x.xConvCentro + '&L_DIRECCION=ACTUAL&X_NOTACTEVA_ACTUAL=' + xNotActEva +
      '&L_MODIFICADO=false&mapCalificacionesModal=' + mapCal;
    // Como la página: estos mapas solo van si Séneca los tiene definidos en ese momento.
    var mNA = glob('mapNotActEva'), mD = glob('mapDeshabilitados');
    if (mNA && mD !== undefined) p += '&mapNotActEva=' + mNA.get(x.xActeva) + '&mapDeshabilitados=' + mD;
    p += '&ACTIVAR_PROCESO=S&SIN_ALUMNO_SIGUIENTE=S';
    var obj = window.jQuery.deparam(p), fd = new FormData();
    Object.keys(obj).forEach(function (k) { fd.append(k, obj[k]); });
    var r = await fetch(new URL('pasen/actividadesevaluables/PMRegCalActEva_2023.jsp', document.baseURI).href,
      { method: 'POST', body: fd, credentials: 'include', cache: 'no-store' });
    if (!r.ok) throw new Error('Séneca respondió ' + r.status + ' al guardar.');
    // Comprobación: se relee la ventana y se cotejan las notas.
    var v2 = await leerModal(xNotActEva), mal = [];
    Object.keys(notas).forEach(function (cod) {
      var c = v2.crits[cod];
      if (c && Math.abs(parseFloat(c.valor) - notas[cod]) > 0.001) mal.push(cod);
    });
    return { modal: v2, estado: mal.length ? 'no-verificado' : 'guardado', mal: mal, faltan: faltan };
  }

  var OPS = {
    llamar: function (a) {
      var f = fnSeneca(a.fn);
      if (!f) throw new Error('Séneca no tiene la función ' + a.fn + ' en esta pantalla.');
      f.apply(null, a.args || []);
      return true;
    },
    actividadesCuaderno: actividadesCuaderno,
    leerModal: function (a) { return leerModal(a.xNotActEva); },
    grabarNotas: function (a) { return grabarNotas(a.xNotActEva, a.notas); }
  };

  window.addEventListener('message', function (ev) {
    var d = ev.data;
    if (ev.source !== window || !d || d.evaSenecaMain !== 'cmd' || !OPS[d.op] || (YO && d.ext && d.ext !== YO)) return;
    Promise.resolve().then(function () { return OPS[d.op](d.args || {}); }).then(function (data) {
      window.postMessage({ evaSenecaMain: 'res', ext: d.ext, id: d.id, ok: true, data: data }, '*');
    }, function (e) {
      window.postMessage({ evaSenecaMain: 'res', ext: d.ext, id: d.id, ok: false, error: String((e && e.message) || e) }, '*');
    });
  });
})();
