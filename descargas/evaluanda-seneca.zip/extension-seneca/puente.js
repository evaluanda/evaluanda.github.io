/*
 * Puente con Evaluanda. Corre en los iframes de googleusercontent.com (donde
 * Apps Script sirve la app) y solo actúa si la página es Evaluanda (tiene
 * #modal-fondo). Se comunica por atributos del <html>, revisados cada medio
 * segundo: Apps Script reescribe el documento al cargarlo (document.open) y eso
 * borra los listeners, así que postMessage no sirve aquí.
 *   data-eva-seneca="<versión>"  ← lo pone la extensión (está instalada)
 *   data-eva-seneca-paquete      ← lo deja Evaluanda (JSON)
 *   data-eva-seneca-recibido     ← responde la extensión ('ok' | 'ko')
 */
(function () {
  'use strict';
  var VERSION = chrome.runtime.getManifest().version;

  function valido(p) {
    return p && p.v === 1 && Array.isArray(p.alumnos) && Array.isArray(p.actividades) &&
      p.actividades.length > 0 && p.categoria && typeof p.categoria.descripcion === 'string';
  }

  function revisar() {
    var r = document.documentElement;
    if (!r || !document.getElementById('modal-fondo')) return;
    if (r.getAttribute('data-eva-seneca') !== VERSION) r.setAttribute('data-eva-seneca', VERSION);
    var txt = r.getAttribute('data-eva-seneca-paquete');
    if (!txt || r.hasAttribute('data-eva-seneca-recibido')) return;
    r.removeAttribute('data-eva-seneca-paquete');
    var p = null;
    try { p = JSON.parse(txt); } catch (e) { /* JSON roto: se responde 'ko' */ }
    if (!valido(p)) return r.setAttribute('data-eva-seneca-recibido', 'ko');
    // Paquete nuevo = progreso nuevo: se descarta lo hecho con el anterior.
    chrome.storage.local.set({ paquete: p, progreso: { acts: {} }, log: [], flujo: null }, function () {
      r.setAttribute('data-eva-seneca-recibido', chrome.runtime.lastError ? 'ko' : 'ok');
    });
  }

  setInterval(revisar, 500);
})();
