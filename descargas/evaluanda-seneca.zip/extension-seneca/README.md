# Evaluanda → Séneca (extensión de Chrome, beta)

Lleva a Séneca lo que se evalúa en Evaluanda:

1. Crea la **categoría** si no existe. Desde una unidad es su código («SdA 01»); desde el Resumen, el trimestre.
2. Crea las **actividades evaluables** que falten, con sus criterios, el sistema «Numérico abierto» y todo el alumnado.
3. Pone las **notas por criterio** de cada alumno/a y las vuelve a leer para comprobarlas.

No borra nada. Lo que no encaja (un alumno/a o un criterio) se salta y se avisa.

## Instalar (beta)

1. Descarga [evaluanda-seneca.zip](https://evaluanda.github.io/descargas/evaluanda-seneca.zip) y descomprímelo. Sale la carpeta `extension-seneca`.
2. En Chrome abre `chrome://extensions` y activa **Modo desarrollador**.
3. Pulsa **Cargar descomprimida** y elige la carpeta.
4. Recarga Evaluanda. En la unidad aparece **Enviar a Séneca** (solo para los correos de `FLAGS.senecaExt`).

## Usar

1. En Evaluanda: **Enviar a Séneca** → elige qué crear, la evaluación, la categoría y la fecha → **Enviar**.
2. Entra en Séneca, con la pestaña **Alumnado** del menú lateral abierta. En el panel **Evaluanda** (abajo a la derecha), pulsa **Empezar**. El panel pasa al centro de la pantalla y la extensión recorre Séneca ella sola por el menú, por detrás:
   1. **Grupos de alumnos/as**: lee tus grupos y te pregunta en cuál volcar las notas.
      - Después, en **Mis alumnos y alumnas**, compara el alumnado del grupo con el de Evaluanda.
      - Si alguno no coincide, te deja emparejarlo a mano. La extensión propone un nombre por parecido.
      - Elegir el grupo y emparejar es lo único que haces tú.
      - Si no tienes grupos cargados, por ejemplo tras grabar o cambiar el horario, los carga y los valida ella, como los botones «Carga de grupos» y «Validar».
   2. **Categoría**: la busca en el desplegable de Actividades y solo va a **Parámetros** si hay que crearla.
   3. **Actividades**: elige el grupo y la evaluación, pulsa **Refrescar** y crea solo las actividades que falten.

   Si repites con la misma clase, no vuelve a preguntar el grupo («cambiar» lo deja elegir otra vez). Tampoco vuelve a cotejar el alumnado si no ha cambiado.
   4. **Cuaderno**: empareja al alumnado por nombre y pone las notas por criterio, comprobándolas después.
3. Al terminar verás cuántas notas se han guardado. El cuaderno de Séneca se refresca para mostrarlas.

Mientras trabaja:
- Séneca se ve difuminada por detrás y hay una barra de progreso.
- Puedes cambiar de pestaña; sigue trabajando.
- Minimizado, queda el icono de Evaluanda en la esquina; mientras trabaja lleva un punto naranja.

Si algo falla, el panel se detiene con un aviso y un botón **Reintentar**. Si te has movido de pantalla, Reintentar vuelve sola a la que tocaba.

## Cómo funciona

| Fichero | Dónde corre | Qué hace |
|---|---|---|
| `puente.js` | Iframe de Evaluanda (`*.googleusercontent.com`) | Marca el `<html>` de la app con `data-eva-seneca` y recoge el paquete que deja en `data-eva-seneca-paquete` (lo guarda en `chrome.storage.local`). Usa atributos, no postMessage: Apps Script reescribe el documento y borra los listeners. |
| `seneca.js` | Séneca (mundo aislado) | Panel, detección de la pantalla, relleno de formularios y progreso. |
| `seneca-main.js` | Séneca (mundo de la página) | Llama a las funciones de Séneca (`nuevo()`, `nueva()`, `aceptar()`) y repite la petición de su ventana de calificar (`PMRegCalActEva_2023.jsp`, modo `GRABAR_NOTA_MODAL`) con sus propios objetos. |

El paquete (`v: 1`) lo genera `mandarPaqueteSeneca_` en `cliente.html`.

Contenido del paquete:

- `alumnos[]`: nombres de Séneca;
- `categoria {descripcion, abreviatura}`;
- `evaluacion`: «1ª Evaluación»…;
- `opciones {mostrar, publicar}`;
- `actividades[]`, cada una con `nombre`, `fecha` (`aaaa-mm-dd`), `criterios[]` y `notas`. `notas` va de índice de alumno a `{código: nota}`.

Si Séneca cambia sus pantallas, los puntos que se rompen están en `pantalla()`, `rellenarActividad()` y `leerModal()`.

Si algo falla, el botón **Informar del fallo** (o «Enviar el registro…» dentro del registro) abre un correo de Gmail a `sgirjim495@g.educaand.es` con la versión, la fase, el error y las últimas líneas del registro. El docente lo revisa antes de enviarlo; el registro puede incluir nombres de alumnado.
