#!/usr/bin/env node
/**
 * Comprobación de la conexión, sin Claude de por medio:
 *
 *     npm run comprobar
 *
 * Llama a tu API de Apps Script y dice si responde. Sirve para separar los dos
 * lados del problema: si esto va bien, lo que falle está en la configuración de
 * Claude Desktop; si falla aquí, está en el proyecto de Apps Script.
 */
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const AQUI = dirname(fileURLToPath(import.meta.url));
let cfg = {};
try { cfg = JSON.parse(readFileSync(join(AQUI, 'config.json'), 'utf8')); } catch { /* opcional */ }
const url = process.env.EVALUANDA_URL || cfg.url;
const token = process.env.EVALUANDA_TOKEN || cfg.token;

if (!url || !token) {
  console.error('✗ Falta la configuración.');
  console.error('  Crea config.json (copia config.ejemplo.json) o define');
  console.error('  EVALUANDA_URL y EVALUANDA_TOKEN.');
  process.exit(1);
}
if (!/\/exec$/.test(url)) {
  console.error('✗ La URL debería acabar en /exec. La tuya acaba en: ' + url.slice(-12));
  console.error('  Copia la URL de «Implementar → Gestionar implementaciones».');
  process.exit(1);
}

try {
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token, accion: 'ping' })
  });
  const texto = await resp.text();
  let json;
  try {
    json = JSON.parse(texto);
  } catch {
    console.error('✗ La API no ha devuelto JSON (código HTTP ' + resp.status + ').');
    console.error('  Casi seguro: el despliegue no es «Ejecutar como: yo» +');
    console.error('  «Acceso: cualquier usuario», y Google devuelve una página de login.');
    process.exit(1);
  }
  if (!json.ok) {
    if (json.error === 'token') {
      console.error('✗ Token incorrecto: no coincide con la propiedad API_TOKEN del script.');
    } else {
      console.error('✗ La API ha respondido con un error: ' + json.error);
      if (/CIF_KEY/.test(json.error || '')) {
        console.error('  Añade la propiedad CIF_KEY (Evaluanda › Ajustes › Conector de IA › Clave de cifrado).');
      }
      if (/no trae tu cuaderno|Acción desconocida/.test(json.error || '')) {
        console.error('  Descarga el código desde Evaluanda (Ajustes › Conector de IA) y pégalo en tu proyecto.');
      }
    }
    process.exit(1);
  }
  // Y la lista de herramientas (servidor 3.0): una API anterior no la da.
  const h = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token, accion: 'herramientas' }) }).then((r) => r.json()).catch(() => null);
  if (!h || !h.ok) {
    console.error('✗ La API responde, pero no da la lista de herramientas: es anterior al servidor 3.0.');
    console.error('  Descarga el código desde Evaluanda (Ajustes › Conector de IA), pégalo y publícalo como versión nueva.');
    process.exit(1);
  }
  console.log('✓ Conexión correcta (' + h.datos.herramientas.length + ' herramientas).');
  console.log('  Cuaderno: ' + json.datos.cuaderno + (json.datos.version ? ' (API ' + json.datos.version + ')' : ''));
  console.log('\nYa puedes enchufarlo a Claude Desktop (paso 3 del README).');
} catch (e) {
  console.error('✗ No se pudo conectar: ' + e.message);
  process.exit(1);
}
