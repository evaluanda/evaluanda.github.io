#!/usr/bin/env node
/**
 * Servidor MCP de Evaluanda.
 *
 * Corre en TU ordenador. Claude lo arranca solo y habla con él por la entrada y
 * la salida estándar (transporte stdio): no hay nada publicado en internet.
 * Para leer y escribir, llama a tu proyecto de Apps Script «Evaluanda — API»
 * con un token secreto que no sale de este ordenador.
 *
 *   Claude  ──stdio──>  este servidor  ──HTTPS+token──>  Apps Script  ──>  tu cuaderno
 *
 * Qué ve y hace la IA: tus clases, tu planificación (unidades, sesiones,
 * reuniones, tareas), tus unidades de evaluación con sus actividades, carpetas y
 * rúbricas, y los criterios del currículo. Puede crear y editar todo eso, y
 * clonar unidades. Qué NO: ver tu alumnado o sus calificaciones (no hay ninguna
 * herramienta que los exponga, ni aquí ni en la API) ni borrar nada.
 *
 * Las herramientas NO están escritas aquí: las define la API (tools/mcp/api.js
 * en el repositorio de la app) y este servidor se las pide al arrancar y las
 * guarda en herramientas.json. Así una herramienta nueva llega con el código de
 * la API, sin actualizar este servidor; y si la API tarda o falla, se usa la
 * lista guardada.
 *
 * Puesta en marcha: https://evaluanda.github.io/conectar-ia.html
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';

const AQUI = dirname(fileURLToPath(import.meta.url));

// --- configuración ---------------------------------------------------------
// Se admite por variables de entorno (lo cómodo en la configuración de Claude)
// o por config.json (lo cómodo para probar a mano).
function cargarConfig() {
  let cfg = {};
  try {
    cfg = JSON.parse(readFileSync(join(AQUI, 'config.json'), 'utf8'));
  } catch {
    // Sin config.json no pasa nada: se usan las variables de entorno.
  }
  const url = process.env.EVALUANDA_URL || cfg.url;
  const token = process.env.EVALUANDA_TOKEN || cfg.token;
  if (!url || !token) {
    // A stderr: stdout es el canal del protocolo y escribir ahí lo rompería.
    console.error(
      'Falta la configuración. Define EVALUANDA_URL y EVALUANDA_TOKEN, o crea ' +
      'un config.json junto a index.js (mira config.ejemplo.json).');
    process.exit(1);
  }
  return { url, token, mapa: cfg.mapa || MAPA_POR_DEFECTO };
}

// El mapa curricular es público: se lee de la web pública de Evaluanda (la misma
// que usa la app, ver Instancia.gs), sin pasar por Apps Script. El repositorio
// del código es privado: sus raw.githubusercontent.com ya no responden.
const MAPA_POR_DEFECTO = [
  'https://evaluanda.github.io/data/mapa-curricular.json',
  'https://evaluanda.github.io/data/mapa-secundaria.json'
];

const CFG = cargarConfig();

// --- llamada a la API de Apps Script ---------------------------------------
async function api(accion, datos = {}) {
  const resp = await fetch(CFG.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    // Apps Script responde 302 hacia googleusercontent; fetch lo sigue solo.
    body: JSON.stringify({ ...datos, token: CFG.token, accion }), // los argumentos no pisan token ni acción
    // Apps Script corta a los 6 minutos: sin respuesta para entonces, no llegará.
    signal: AbortSignal.timeout(370000)
  });
  const texto = await resp.text();
  let json;
  try {
    json = JSON.parse(texto);
  } catch {
    // El error típico: la URL no es la del despliegue /exec, o el despliegue
    // no es «cualquier usuario» y Google devuelve una página de login.
    throw new Error(
      'La API no devolvió JSON. Revisa que EVALUANDA_URL acabe en /exec y que ' +
      'el despliegue sea «Ejecutar como: yo» y «Acceso: cualquier usuario».');
  }
  if (!json.ok) {
    if (json.error === 'token') throw new Error('Token incorrecto: no coincide con API_TOKEN.');
    throw new Error(json.error || 'Error desconocido en la API.');
  }
  return json.datos;
}

// --- mapa curricular (criterios de evaluación) -----------------------------
let mapaCache = null;
async function criterios(curso, area) {
  if (!mapaCache) {
    const partes = await Promise.all(CFG.mapa.map(async (u) => {
      const r = await fetch(u);
      if (!r.ok) throw new Error('No se pudo descargar el mapa curricular: ' + u);
      return r.json();
    }));
    mapaCache = partes.flat();
  }
  const norm = (s) => String(s || '').trim().toLowerCase();
  return mapaCache.filter((c) =>
    (!curso || norm(c.curso) === norm(curso)) &&
    (!area || norm(c.area) === norm(area)));
}

// --- servidor --------------------------------------------------------------
// Bajo nivel (Server) y no McpServer: las herramientas llegan como esquemas JSON
// desde la API y cambian sin tocar este archivo.
const server = new Server({ name: 'evaluanda', version: '3.0.0' }, { capabilities: { tools: { listChanged: true } } });
const texto = (v) => ({ content: [{ type: 'text', text: JSON.stringify(v ?? null, null, 2) }] });

// Herramientas que resuelve este servidor (sin pasar por la API).
const LOCALES = {
  comprobar_conexion: {
    def: { name: 'comprobar_conexion', title: 'Comprobar la conexión',
      description: 'Verifica que el servidor llega a Evaluanda (y la versión de la API). Útil al configurarlo.',
      inputSchema: { type: 'object', properties: {} } },
    // Con el aviso de por qué faltan herramientas, si es el caso (API anterior a la 3.0…).
    run: async () => (falloLista ? { ...(await api('ping')), aviso: falloLista } : api('ping'))
  },
  listar_criterios: {
    def: { name: 'listar_criterios', title: 'Listar criterios del currículo',
      description: 'Criterios oficiales del currículo andaluz (LOMLOE) para un curso y una materia, sin pasar por ' +
        'una clase. Si hay clase, mejor criterios_clase.',
      inputSchema: { type: 'object', required: ['curso'], properties: {
        curso: { type: 'string', description: 'Curso, p. ej. "5º Primaria"' },
        area: { type: 'string', description: 'Materia; sin ella, todas las del curso' } } } },
    run: async ({ curso, area }) => {
      const encontrados = await criterios(curso, area);
      if (encontrados.length) return encontrados.map((c) => ({ codigo: c.codigo, texto: c.texto, area: c.area }));
      // Sin resultados se devuelve lo que SÍ existe, para que la IA se corrija sola
      // (en 5º de Primaria la materia es «Conocimiento del Medio»…).
      const delCurso = await criterios(curso);
      if (delCurso.length) {
        return { aviso: 'Ese curso existe, pero no esa materia. Usa uno de estos nombres tal cual.',
          materias: [...new Set(delCurso.map((c) => c.area))].sort() };
      }
      return { aviso: 'No encuentro ese curso. Usa uno de estos nombres tal cual.',
        cursos: [...new Set((await criterios()).map((c) => c.curso))].sort() };
    }
  }
};

// Herramientas de la API: las guardadas, y al arrancar se piden de nuevo.
const GUARDADAS = join(AQUI, 'herramientas.json');
/** Lista válida de la API (sin las que resuelve este servidor), o []. */
const validas = (l) => (Array.isArray(l) ? l : []).filter((t) =>
  t && typeof t.name === 'string' && !LOCALES[t.name] && t.inputSchema && t.inputSchema.type === 'object');
let remotas = [];
try { remotas = validas(JSON.parse(readFileSync(GUARDADAS, 'utf8')).herramientas); } catch { /* primera vez o archivo roto */ }
let falloLista = '';

/** Pide la lista a la API; si cambia, la guarda y avisa al cliente. Nunca lanza. */
function pedirLista() {
  return api('herramientas').then((r) => {
    falloLista = '';
    const nuevas = validas(r && r.herramientas);
    if (!nuevas.length) throw new Error('la API no devolvió herramientas');
    const cambian = JSON.stringify(nuevas) !== JSON.stringify(remotas);
    remotas = nuevas;
    if (!cambian) return;
    try { writeFileSync(GUARDADAS, JSON.stringify({ version: r.version, herramientas: nuevas }, null, 1)); }
    catch { /* carpeta de solo lectura: se pedirán cada vez */ }
    server.sendToolListChanged().catch(() => { /* aún sin cliente conectado: la pedirá */ });
  }).catch((e) => {
    falloLista = /Acción desconocida/.test(e.message)
      ? 'Tu API es anterior al servidor 3.0 y no da la lista de herramientas: descarga el código desde ' +
        'Evaluanda (Ajustes › Conector de IA), pégalo y publícalo como versión nueva.'
      : 'No se pudo pedir la lista de herramientas a la API: ' + e.message;
    // A stderr: stdout es el canal del protocolo.
    console.error(falloLista + (remotas.length ? ' Uso la lista guardada.' : ''));
  });
}
let pedidas = pedirLista();

server.setRequestHandler(ListToolsRequestSchema, async () => {
  // Sin lista (primera vez, o la API no respondió): se vuelve a pedir y se espera (poco).
  if (!remotas.length) {
    if (falloLista) pedidas = pedirLista();
    await Promise.race([pedidas, new Promise((r) => setTimeout(r, 25000))]);
  }
  return { tools: Object.values(LOCALES).map((l) => l.def).concat(remotas) };
});

server.setRequestHandler(CallToolRequestSchema, async (req) => {
  const { name, arguments: args = {} } = req.params;
  try {
    return texto(LOCALES[name] ? await LOCALES[name].run(args) : await api(name, args));
  } catch (e) {
    return { isError: true, content: [{ type: 'text', text: e.message }] };
  }
});

await server.connect(new StdioServerTransport());
