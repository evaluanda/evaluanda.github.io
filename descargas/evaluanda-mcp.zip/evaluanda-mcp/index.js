#!/usr/bin/env node
/**
 * Servidor MCP de Evaluanda.
 *
 * Corre en TU ordenador. Claude lo arranca solo y habla con él por la entrada y
 * la salida estándar (transporte stdio): no hay nada publicado en internet.
 * Para leer y escribir, llama a tu proyecto de Apps Script «Evaluanda — API»
 * con un token secreto que no sale de este ordenador.
 *
 *   Claude  ──stdio──>  este servidor  ──HTTPS+token──>  Apps Script  ──>  tu cuaderno
 *
 * Qué ve y hace la IA: tus clases, tu planificación (unidades, sesiones,
 * reuniones, tareas), tus unidades de evaluación con sus actividades, carpetas y
 * rúbricas, y los criterios del currículo. Puede crear y editar todo eso, y
 * clonar unidades. Qué NO: ver tu alumnado o sus calificaciones (no hay ninguna
 * herramienta que los exponga, ni aquí ni en la API) ni borrar nada.
 *
 * Puesta en marcha: https://evaluanda.github.io/conectar-ia.html
 */
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';

const AQUI = dirname(fileURLToPath(import.meta.url));

// --- configuración ---------------------------------------------------------
// Se admite por variables de entorno (lo cómodo en la configuración de Claude)
// o por config.json (lo cómodo para probar a mano).
function cargarConfig() {
  let cfg = {};
  try {
    cfg = JSON.parse(readFileSync(join(AQUI, 'config.json'), 'utf8'));
  } catch {
    // Sin config.json no pasa nada: se usan las variables de entorno.
  }
  const url = process.env.EVALUANDA_URL || cfg.url;
  const token = process.env.EVALUANDA_TOKEN || cfg.token;
  if (!url || !token) {
    // A stderr: stdout es el canal del protocolo y escribir ahí lo rompería.
    console.error(
      'Falta la configuración. Define EVALUANDA_URL y EVALUANDA_TOKEN, o crea ' +
      'un config.json junto a index.js (mira config.ejemplo.json).');
    process.exit(1);
  }
  return { url, token, mapa: cfg.mapa || MAPA_POR_DEFECTO };
}

// El mapa curricular es público: se lee de la web pública de Evaluanda (la misma
// que usa la app, ver Instancia.gs), sin pasar por Apps Script. El repositorio
// del código es privado: sus raw.githubusercontent.com ya no responden.
const MAPA_POR_DEFECTO = [
  'https://evaluanda.github.io/data/mapa-curricular.json',
  'https://evaluanda.github.io/data/mapa-secundaria.json'
];

const CFG = cargarConfig();

// --- llamada a la API de Apps Script ---------------------------------------
async function api(accion, datos = {}) {
  const resp = await fetch(CFG.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    // Apps Script responde 302 hacia googleusercontent; fetch lo sigue solo.
    body: JSON.stringify({ token: CFG.token, accion, ...datos }),
    // Apps Script corta a los 6 minutos: sin respuesta para entonces, no llegará.
    signal: AbortSignal.timeout(370000)
  });
  const texto = await resp.text();
  let json;
  try {
    json = JSON.parse(texto);
  } catch {
    // El error típico: la URL no es la del despliegue /exec, o el despliegue
    // no es «cualquier usuario» y Google devuelve una página de login.
    throw new Error(
      'La API no devolvió JSON. Revisa que EVALUANDA_URL acabe en /exec y que ' +
      'el despliegue sea «Ejecutar como: yo» y «Acceso: cualquier usuario».');
  }
  if (!json.ok) {
    if (json.error === 'token') throw new Error('Token incorrecto: no coincide con API_TOKEN.');
    throw new Error(json.error || 'Error desconocido en la API.');
  }
  return json.datos;
}

// --- mapa curricular (criterios de evaluación) -----------------------------
let mapaCache = null;
async function criterios(curso, area) {
  if (!mapaCache) {
    const partes = await Promise.all(CFG.mapa.map(async (u) => {
      const r = await fetch(u);
      if (!r.ok) throw new Error('No se pudo descargar el mapa curricular: ' + u);
      return r.json();
    }));
    mapaCache = partes.flat();
  }
  const norm = (s) => String(s || '').trim().toLowerCase();
  return mapaCache.filter((c) =>
    (!curso || norm(c.curso) === norm(curso)) &&
    (!area || norm(c.area) === norm(area)));
}

// --- servidor --------------------------------------------------------------
const server = new McpServer({ name: 'evaluanda', version: '2.0.0' });

const texto = (v) => ({ content: [{ type: 'text', text: JSON.stringify(v, null, 2) }] });
const CONFIRMA = 'Escribe en el cuaderno real del profesor: enséñale antes lo que vas a hacer y espera su sí. ';
const NO_BORRA = 'No existe borrar a propósito: eso se hace desde la app. ';

/** Herramienta que llama a una acción de la API. `datos` traduce los argumentos (por defecto, tal cual). */
function herramienta(nombre, title, description, inputSchema, datos = (a) => a) {
  server.registerTool(nombre, { title, description, inputSchema },
    async (args) => texto(await api(nombre, datos(args || {}))));
}
const id = (que) => z.string().describe(que);
const opc = (s, que) => s.optional().describe(que);
const lista = (que) => z.array(z.string()).describe(que);

// ---- clases, planificación y sesiones -------------------------------------
herramienta('listar_clases', 'Listar clases',
  'Las clases del profesor en el curso activo: materia, curso, grupo y horario semanal. ' +
  'El claseId es el que se usa en el resto de herramientas (unidades, sesiones, criterios).', {});

herramienta('listar_unidades', 'Listar unidades de planificación',
  'Unidades del PLANIFICADOR (contenedor de las sesiones), opcionalmente por materia y curso. ' +
  'Las unidades de evaluación de una clase (con sus actividades) son otra cosa: listar_unidades_clase.', {
    area: opc(z.string(), 'Materia, p. ej. "Ciencias de la Naturaleza"'),
    curso: opc(z.string(), 'Curso, p. ej. "5º Primaria"')
  });

herramienta('listar_sesiones', 'Listar sesiones',
  'Sesiones de clase planificadas, en su orden. Con unidadId, solo las de esa unidad de planificación. ' +
  'Úsalo SIEMPRE antes de proponer cambios. Las descripciones llegan en Markdown.', {
    unidadId: opc(z.string(), 'Id de la unidad de planificación (de listar_unidades)')
  });

// Formato de la descripción, para que el modelo no lo tenga que adivinar.
const FORMATO_DESC =
  'La descripción va en Markdown (listar_sesiones la da igual): **negrita**, *cursiva*, <u>subrayado</u>, ' +
  '~~tachado~~, ==resaltado==, # / ## / ### títulos, listas «- » o «1. » (sangría de 2 espacios para ' +
  'sublistas), casillas «- [ ] » / «- [x] », enlaces [texto](url) y URLs sueltas, imágenes ![](https://…), ' +
  '![](drive:ID) o ![](youtube:ID) con {w=300} detrás para el ancho, y una línea solo con <br> para dejar ' +
  'una línea en blanco. Deja una línea vacía entre párrafos. Al editar, parte de la descripción que ' +
  'listar_sesiones devuelve y conserva lo que no cambies (imágenes incluidas).';
const FECHAS = z.array(z.object({ claseId: id('De listar_clases'), fecha: id('AAAA-MM-DD') }));

herramienta('crear_sesion', 'Crear una sesión',
  'Crea una sesión de clase (si su día ya está lleno, la app empuja las siguientes, como al crearla a mano). ' +
  CONFIRMA + FORMATO_DESC, {
    titulo: id('Título de la sesión'),
    descripcion: opc(z.string(), 'Desarrollo de la sesión, en Markdown'),
    criterios: opc(z.array(z.string()), 'Códigos de criterios_clase'),
    unidadId: opc(z.string(), 'Unidad de planificación a la que pertenece'),
    fechas: opc(FECHAS, 'En qué clases y qué día se dará')
  }, (s) => ({ sesion: s }));

herramienta('editar_sesion', 'Editar una sesión',
  'Cambia una sesión de clase. Solo se tocan los campos que envíes. (Si listar_sesiones dijera ' +
  'descripcionEditable: false, su descripción no se puede cambiar desde aquí.) ' + NO_BORRA + FORMATO_DESC, {
    sesionId: id('De listar_sesiones'),
    titulo: z.string().optional(), descripcion: z.string().optional(),
    criterios: z.array(z.string()).optional(), unidadId: z.string().optional(),
    fechas: opc(FECHAS, 'Fecha de esas clases (o las añade); las que no pongas se quedan como están. ' +
      'Quitar una clase de la sesión, desde la app')
  }, ({ sesionId, ...cambios }) => ({ sesionId, cambios }));

herramienta('listar_eventos', 'Listar reuniones y eventos',
  'Reuniones, eventos y avisos del planificador con su fecha y hora. Su sesionId sirve para ligarles una tarea.', {
    desde: opc(z.string(), 'AAAA-MM-DD'), hasta: opc(z.string(), 'AAAA-MM-DD')
  });

// ---- tareas del profe -------------------------------------------------------
const CAMPOS_TAREA = {
  vence: opc(z.string(), 'Día en que vence, AAAA-MM-DD ("" la deja sin fecha)'),
  inicio: opc(z.string(), 'Desde cuándo se muestra, AAAA-MM-DD (por defecto, hoy)'),
  clases: opc(z.array(z.string()), 'claseId de listar_clases ([] = ninguna)'),
  sesionId: opc(z.string(), 'Sesión, reunión o evento al que va ligada ("" = ninguno)')
};
herramienta('listar_tareas', 'Listar tareas',
  'Tareas del profesor (pendientes con vencimiento, clases y sesión o reunión opcionales).', {
    desde: opc(z.string(), 'Vencen (o empiezan) desde este día, AAAA-MM-DD'),
    hasta: opc(z.string(), '…hasta este día, AAAA-MM-DD'),
    claseId: opc(z.string(), 'Solo las de esta clase'),
    pendientes: opc(z.boolean(), 'true = solo las no hechas')
  });
herramienta('crear_tarea', 'Crear una tarea', 'Apunta una tarea. ' + CONFIRMA,
  { texto: id('Qué hay que hacer (máx. 300 caracteres)'), ...CAMPOS_TAREA }, (t) => ({ tarea: t }));
herramienta('editar_tarea', 'Editar una tarea',
  'Cambia texto, fechas, clases, sesión/reunión o si está hecha. Solo se tocan los campos que envíes. ' + NO_BORRA,
  { tareaId: id('De listar_tareas'), texto: z.string().optional(), hecha: z.boolean().optional(), ...CAMPOS_TAREA },
  ({ tareaId, ...cambios }) => ({ tareaId, cambios }));

// ---- currículo --------------------------------------------------------------
herramienta('criterios_clase', 'Criterios de una clase',
  'Criterios de evaluación de la clase (su curso y materia; en clases mixtas o con ACS, los de todos sus niveles, ' +
  'y los criterios propios del profe). Usa SOLO estos códigos: no inventes códigos.', { claseId: id('De listar_clases') });

herramienta('saberes_criterios', 'Saberes básicos de unos criterios',
  'Saberes básicos (y contenidos) que concretan unos criterios: los códigos que admite «saberes» en una actividad.',
  { criterios: lista('Códigos de criterio') });

server.registerTool('listar_criterios', {
  title: 'Listar criterios del currículo',
  description: 'Criterios oficiales del currículo andaluz (LOMLOE) para un curso y una materia, sin pasar por ' +
    'una clase. Si hay clase, mejor criterios_clase.',
  inputSchema: {
    curso: id('Curso, p. ej. "5º Primaria"'),
    area: opc(z.string(), 'Materia; sin ella, todas las del curso')
  }
}, async ({ curso, area }) => {
  const encontrados = await criterios(curso, area);
  if (!encontrados.length) {
    // Sin resultados se devuelve lo que SÍ existe, para que la IA se corrija sola
    // (en 5º de Primaria la materia es «Conocimiento del Medio»…).
    const delCurso = await criterios(curso);
    if (delCurso.length) {
      return texto({ aviso: 'Ese curso existe, pero no esa materia. Usa uno de estos nombres tal cual.',
        materias: [...new Set(delCurso.map((c) => c.area))].sort() });
    }
    return texto({ aviso: 'No encuentro ese curso. Usa uno de estos nombres tal cual.',
      cursos: [...new Set((await criterios()).map((c) => c.curso))].sort() });
  }
  return texto(encontrados.map((c) => ({ codigo: c.codigo, texto: c.texto, area: c.area })));
});

// ---- unidades de evaluación (cuaderno) ---------------------------------------
herramienta('listar_unidades_clase', 'Unidades de una clase',
  'Unidades de evaluación de una clase (las del cuaderno), con su número, carpetas y nº de actividades.',
  { claseId: id('De listar_clases') });

herramienta('ver_unidad', 'Ver una unidad',
  'Una unidad de evaluación completa: sus actividades (tipo, criterios, saberes, peso, carpeta, rúbrica…), ' +
  'carpetas, rúbricas que usa y los criterios de la clase que aún no recoge ninguna de sus actividades. ' +
  'Sin alumnado ni notas.', { unidadId: id('De listar_unidades_clase') });

herramienta('cobertura_criterios', 'Cobertura de criterios de una clase',
  'Cada criterio de la clase con las actividades (y unidades) que lo evalúan: para ver qué falta o qué se repite.',
  { claseId: id('De listar_clases') });

herramienta('crear_unidad', 'Crear una unidad', 'Crea una unidad de evaluación en una clase. ' + CONFIRMA, {
  claseId: id('De listar_clases'), nombre: id('Nombre de la unidad'),
  numero: opc(z.number().int().min(0).max(999), 'Su número (UD 3…; 0 = evaluación inicial). Si ya lo tiene otra, ' +
    'esa y las consecutivas suben uno. Sin él, va la última.')
});

herramienta('editar_unidad', 'Editar una unidad', 'Cambia el nombre o el número de una unidad. ' + NO_BORRA, {
  unidadId: id('De listar_unidades_clase'), nombre: z.string().optional(),
  numero: opc(z.number().int().min(0).max(999), 'Nuevo número (desplaza como al crear)')
});

herramienta('clonar_unidad', 'Clonar una unidad',
  'Copia una unidad con sus actividades, carpetas y rúbricas (nunca notas). Sin claseIds, en su misma clase ' +
  '(«(copia)»); con claseIds, en esas clases, adaptando los criterios a su nivel (4.5.1 → 6.5.1; sin equivalente, ' +
  'la actividad queda sin ese criterio). ' + CONFIRMA, {
    unidadId: id('De listar_unidades_clase'),
    claseIds: opc(z.array(z.string()), 'Clases de destino (de listar_clases)')
  });

// ---- carpetas -----------------------------------------------------------------
const CALCULO = z.enum(['media', 'suma', 'max', 'min', 'ponderada']);
const CAMPOS_CARPETA = {
  color: opc(z.string(), 'Color #rrggbb'),
  criterios: opc(z.array(z.string()), 'Criterios de la carpeta (carpeta-instrumento); vacía = solo agrupa'),
  calculo: opc(CALCULO, 'Cómo resume sus columnas (por defecto, media)')
};
herramienta('crear_carpeta', 'Crear una carpeta de columnas',
  'Agrupa columnas (actividades) de una unidad en una carpeta. ' + CONFIRMA, {
    unidadId: id('De listar_unidades_clase'), nombre: id('Nombre (máx. 40)'),
    actividadIds: opc(z.array(z.string()), 'Actividades que entran ya en ella'), ...CAMPOS_CARPETA
  });
herramienta('editar_carpeta', 'Editar una carpeta', 'Cambia nombre, color, criterios o cálculo. ' + NO_BORRA, {
  unidadId: id('De listar_unidades_clase'), carpetaId: id('De ver_unidad'), nombre: z.string().optional(), ...CAMPOS_CARPETA
});
herramienta('mover_a_carpeta', 'Mover actividades a una carpeta',
  'Mete actividades en una carpeta de su unidad, o las saca (carpetaId "").', {
    unidadId: id('De listar_unidades_clase'), carpetaId: id('De ver_unidad ("" = fuera de carpeta)'),
    actividadIds: lista('Actividades a mover')
  });

// ---- actividades --------------------------------------------------------------
const TIPO = z.enum(['items', 'nota', 'check', 'contador', 'escala', 'escalaInf', 'escalaBRM', 'texto', 'rubrica'])
  .describe('items: N ítems (nota = conseguidos/N·10); nota: 0-10; check: sí/no; contador: veces; escala: 1-5; ' +
    'escalaInf: escala de Infantil; escalaBRM: bien/regular/mal; texto: observación (no puntúa); rubrica: con una rúbrica del banco');
const CAMPOS_ACT = {
  nombre: z.string().optional(),
  criterios: opc(z.array(z.string()), 'Códigos de criterios_clase (vacío = informativa)'),
  saberes: opc(z.array(z.string()), 'Saberes básicos (de saberes_criterios)'),
  numItems: opc(z.number(), 'Nº de ítems (items, obligatorio) o máximo (contador)'),
  peso: opc(z.number().min(0), 'Peso en la nota (1 = normal; 0 = no cuenta)'),
  fecha: opc(z.string(), 'AAAA-MM-DD ("" = sin fecha)'),
  carpetaId: opc(z.string(), 'Carpeta de la unidad (de ver_unidad)'),
  color: opc(z.string(), 'Color #rrggbb de la columna'),
  notaPorCriterio: opc(z.boolean(), 'Nota distinta por criterio (con 2 o más criterios)'),
  rubricaId: opc(z.string(), 'Rúbrica del banco (tipo rubrica)'),
  criterioPorIndicador: opc(z.array(z.string()), 'Tipo rubrica: un criterio por indicador, en su orden')
};
herramienta('crear_actividades', 'Crear actividades',
  'Crea una o varias actividades (columnas de evaluación) en una unidad, al final y en el orden dado. ' + CONFIRMA, {
    unidadId: id('De listar_unidades_clase'),
    actividades: z.array(z.object({ ...CAMPOS_ACT, nombre: id('Nombre'), tipo: TIPO })).describe('Máximo 40')
  });
herramienta('editar_actividad', 'Editar una actividad',
  'Cambia una actividad: solo los campos que envíes. El tipo no (se cambia en la app), ni la nota por criterio ' +
  'si la actividad ya tiene notas. ' + NO_BORRA, {
    actividadId: id('De ver_unidad'), ...CAMPOS_ACT
  }, ({ actividadId, ...cambios }) => ({ actividadId, cambios }));
herramienta('duplicar_actividad', 'Duplicar una actividad', 'Copia una actividad en su misma unidad (sin notas).', {
  actividadId: id('De ver_unidad'), nombre: opc(z.string(), 'Nombre de la copia (por defecto, «… (copia)»)')
});
herramienta('copiar_actividad', 'Copiar una actividad a otra unidad',
  'Copia una actividad (sin notas) a otra unidad, también de otra clase (adapta los criterios a su nivel).', {
    actividadId: id('De ver_unidad'), unidadId: id('Unidad de destino'), nombre: z.string().optional()
  });
herramienta('reordenar_actividades', 'Reordenar actividades',
  'Cambia el orden de las columnas de una unidad: pasa TODAS sus actividades en el orden nuevo.', {
    unidadId: id('De listar_unidades_clase'), actividadIds: lista('Todas, en el orden nuevo')
  });

// ---- rúbricas ---------------------------------------------------------------
const NIVELES = z.array(z.object({ etiqueta: z.string(), valor: z.number().describe('Nota 0-10 del nivel') }))
  .describe('La escala, de menos a más (mínimo 2)');
const INDICADORES = z.array(z.object({
  texto: id('Qué se valora'), peso: opc(z.number().min(0), 'Peso en % (por defecto, reparto igual que suma 100)'),
  descriptores: opc(z.array(z.string()), 'Descripción de cada nivel, en el orden de los niveles')
}));
herramienta('listar_rubricas', 'Listar rúbricas', 'El banco de rúbricas del profesor (resumen; ver_rubrica para el detalle).', {});
herramienta('ver_rubrica', 'Ver una rúbrica', 'Una rúbrica completa: niveles, indicadores y sus descriptores.',
  { rubricaId: id('De listar_rubricas') });
herramienta('crear_rubrica', 'Crear una rúbrica',
  'Añade una rúbrica al banco. Para usarla, crea o edita una actividad de tipo rubrica con su rubricaId. ' + CONFIRMA, {
    nombre: id('Nombre'), niveles: NIVELES, indicadores: INDICADORES,
    criterios: opc(z.array(z.string()), 'Criterios de la rúbrica completa (opcional)')
  }, (r) => ({ rubrica: r }));
herramienta('editar_rubrica', 'Editar una rúbrica',
  'Cambia una rúbrica: solo lo que envíes (indicadores y niveles se sustituyen enteros). Si ya se usa, ' +
  'cambia también cómo puntúa en esas columnas: avísalo. ' + NO_BORRA, {
    rubricaId: id('De listar_rubricas'), nombre: z.string().optional(),
    niveles: NIVELES.optional(), indicadores: INDICADORES.optional(), criterios: z.array(z.string()).optional()
  }, ({ rubricaId, ...cambios }) => ({ rubricaId, cambios }));
herramienta('duplicar_rubrica', 'Duplicar una rúbrica', 'Copia una rúbrica del banco («… (copia)»), para variarla.',
  { rubricaId: id('De listar_rubricas') });

server.registerTool('comprobar_conexion', {
  title: 'Comprobar la conexión',
  description: 'Verifica que el servidor llega a Evaluanda (y la versión de la API). Útil al configurarlo.',
  inputSchema: {}
}, async () => texto(await api('ping')));

await server.connect(new StdioServerTransport());
