#!/usr/bin/env node
/**
 * Servidor MCP de Evaluanda.
 *
 * Corre en TU ordenador. Claude lo arranca solo y habla con él por la entrada y
 * la salida estándar (transporte stdio): no hay nada publicado en internet.
 * Para leer y escribir, llama a tu proyecto de Apps Script «Evaluanda — API»
 * con un token secreto que no sale de este ordenador.
 *
 *   Claude  ──stdio──>  este servidor  ──HTTPS+token──>  Apps Script  ──>  tu cuaderno
 *
 * Qué ve la IA: tu planificación (clases, unidades, sesiones, reuniones,
 * criterios y tareas; el texto de las tareas solo si configuras CIF_KEY).
 * Qué NO ve: tu alumnado y sus calificaciones. No hay ninguna herramienta que
 * los exponga, ni aquí ni en la API.
 *
 * Puesta en marcha: ver README.md de esta carpeta.
 */
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';

const AQUI = dirname(fileURLToPath(import.meta.url));

// --- configuración ---------------------------------------------------------
// Se admite por variables de entorno (lo cómodo en la configuración de Claude)
// o por config.json (lo cómodo para probar a mano).
function cargarConfig() {
  let cfg = {};
  try {
    cfg = JSON.parse(readFileSync(join(AQUI, 'config.json'), 'utf8'));
  } catch {
    // Sin config.json no pasa nada: se usan las variables de entorno.
  }
  const url = process.env.EVALUANDA_URL || cfg.url;
  const token = process.env.EVALUANDA_TOKEN || cfg.token;
  if (!url || !token) {
    // A stderr: stdout es el canal del protocolo y escribir ahí lo rompería.
    console.error(
      'Falta la configuración. Define EVALUANDA_URL y EVALUANDA_TOKEN, o crea ' +
      'un config.json junto a index.js (mira config.ejemplo.json).');
    process.exit(1);
  }
  return { url, token, mapa: cfg.mapa || MAPA_POR_DEFECTO };
}

// El mapa curricular es público: se lee de la web pública de Evaluanda (la misma
// que usa la app, ver Instancia.gs), sin pasar por Apps Script. El repositorio
// del código es privado: sus raw.githubusercontent.com ya no responden.
const MAPA_POR_DEFECTO = [
  'https://evaluanda.github.io/data/mapa-curricular.json',
  'https://evaluanda.github.io/data/mapa-secundaria.json'
];

const CFG = cargarConfig();

// --- llamada a la API de Apps Script ---------------------------------------
async function api(accion, datos = {}) {
  const resp = await fetch(CFG.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    // Apps Script responde 302 hacia googleusercontent; fetch lo sigue solo.
    body: JSON.stringify({ token: CFG.token, accion, ...datos })
  });
  const texto = await resp.text();
  let json;
  try {
    json = JSON.parse(texto);
  } catch {
    // El error típico: la URL no es la del despliegue /exec, o el despliegue
    // no es «cualquier usuario» y Google devuelve una página de login.
    throw new Error(
      'La API no devolvió JSON. Revisa que EVALUANDA_URL acabe en /exec y que ' +
      'el despliegue sea «Ejecutar como: yo» y «Acceso: cualquier usuario».');
  }
  if (!json.ok) {
    if (json.error === 'token') throw new Error('Token incorrecto: no coincide con API_TOKEN.');
    throw new Error(json.error || 'Error desconocido en la API.');
  }
  return json.datos;
}

// --- mapa curricular (criterios de evaluación) -----------------------------
let mapaCache = null;
async function criterios(curso, area) {
  if (!mapaCache) {
    const partes = await Promise.all(CFG.mapa.map(async (u) => {
      const r = await fetch(u);
      if (!r.ok) throw new Error('No se pudo descargar el mapa curricular: ' + u);
      return r.json();
    }));
    mapaCache = partes.flat();
  }
  const norm = (s) => String(s || '').trim().toLowerCase();
  return mapaCache.filter((c) =>
    (!curso || norm(c.curso) === norm(curso)) &&
    (!area || norm(c.area) === norm(area)));
}

// --- servidor --------------------------------------------------------------
const server = new McpServer({ name: 'evaluanda', version: '1.1.0' });

const texto = (v) => ({ content: [{ type: 'text', text: JSON.stringify(v, null, 2) }] });

server.registerTool('listar_clases', {
  title: 'Listar clases',
  description: 'Las clases del profesor: materia, grupo y horario semanal. ' +
    'El claseId que devuelve es el que hay que usar para programar sesiones.',
  inputSchema: {}
}, async () => texto(await api('listar_clases')));

server.registerTool('listar_unidades', {
  title: 'Listar unidades de planificación',
  description: 'Unidades didácticas del profesor, opcionalmente filtradas por ' +
    'materia y curso. Son el contenedor de las sesiones.',
  inputSchema: {
    area: z.string().optional().describe('Materia, p. ej. "Ciencias de la Naturaleza"'),
    curso: z.string().optional().describe('Curso, p. ej. "5º Primaria"')
  }
}, async ({ area, curso }) => texto(await api('listar_unidades', { area, curso })));

server.registerTool('listar_sesiones', {
  title: 'Listar sesiones',
  description: 'Sesiones de clase planificadas, en su orden. Con unidadId, solo ' +
    'las de esa unidad. Úsalo SIEMPRE antes de proponer cambios, para saber qué hay. ' +
    'Las descripciones llegan en Markdown, con su formato.',
  inputSchema: {
    unidadId: z.string().optional().describe('Id de la unidad (de listar_unidades)')
  }
}, async ({ unidadId }) => texto(await api('listar_sesiones', { unidadId })));

server.registerTool('listar_criterios', {
  title: 'Listar criterios de evaluación',
  description: 'Criterios oficiales del currículo de Andalucía (LOMLOE) para un ' +
    'curso y una materia. Usa SOLO estos códigos al crear o editar sesiones: no ' +
    'inventes códigos.',
  inputSchema: {
    curso: z.string().describe('Curso, p. ej. "5º Primaria"'),
    area: z.string().optional().describe('Materia; sin ella, todas las del curso')
  }
}, async ({ curso, area }) => {
  const lista = await criterios(curso, area);
  if (!lista.length) {
    // Sin resultados se devuelve lo que SÍ existe, para que la IA se corrija
    // sola en vez de insistir: los nombres oficiales no siempre son los que uno
    // diría (en 5º de Primaria la materia es «Conocimiento del Medio»).
    const delCurso = await criterios(curso);
    if (delCurso.length) {
      return texto({
        aviso: 'Ese curso existe, pero no esa materia. Usa uno de estos nombres tal cual.',
        materias: [...new Set(delCurso.map((c) => c.area))].sort()
      });
    }
    return texto({
      aviso: 'No encuentro ese curso. Usa uno de estos nombres tal cual.',
      cursos: [...new Set((await criterios()).map((c) => c.curso))].sort()
    });
  }
  return texto(lista.map((c) => ({ codigo: c.codigo, texto: c.texto, area: c.area })));
});

// Formato de la descripción, para que el modelo no lo tenga que adivinar.
const FORMATO_DESC =
  'La descripción admite Markdown y se convierte al formato del cuaderno: ' +
  '**negrita**, *cursiva*, listas con «- » o «1. », enlaces [texto](url) y URLs ' +
  'sueltas. Para subrayar, <u>así</u> (Markdown no lo tiene). Deja una línea en ' +
  'blanco entre párrafos.';

server.registerTool('crear_sesion', {
  title: 'Crear una sesión',
  description: 'Crea una sesión de clase. Antes de usarla, confirma con el ' +
    'profesor el título, la descripción y los criterios: escribe en su cuaderno real. ' +
    FORMATO_DESC,
  inputSchema: {
    titulo: z.string().describe('Título de la sesión'),
    descripcion: z.string().optional().describe('Desarrollo de la sesión, en Markdown'),
    criterios: z.array(z.string()).optional().describe('Códigos de listar_criterios'),
    unidadId: z.string().optional().describe('Unidad a la que pertenece'),
    fechas: z.array(z.object({
      claseId: z.string().describe('De listar_clases'),
      fecha: z.string().describe('AAAA-MM-DD')
    })).optional().describe('En qué clases y qué día se dará')
  }
}, async (s) => texto(await api('crear_sesion', { sesion: s })));

server.registerTool('editar_sesion', {
  title: 'Editar una sesión',
  description: 'Cambia una sesión existente. Solo se tocan los campos que envíes. ' +
    'No existe borrar a propósito: eso se hace desde la app. ' + FORMATO_DESC,
  inputSchema: {
    sesionId: z.string().describe('De listar_sesiones'),
    titulo: z.string().optional(),
    descripcion: z.string().optional(),
    criterios: z.array(z.string()).optional(),
    unidadId: z.string().optional(),
    fechas: z.array(z.object({ claseId: z.string(), fecha: z.string() })).optional()
  }
}, async ({ sesionId, ...cambios }) => texto(await api('editar_sesion', { sesionId, cambios })));

server.registerTool('listar_eventos', {
  title: 'Listar reuniones y eventos',
  description: 'Reuniones, eventos y avisos del planificador con su fecha y hora. ' +
    'Su sesionId sirve para vincular una tarea a una reunión o evento.',
  inputSchema: {
    desde: z.string().optional().describe('AAAA-MM-DD'),
    hasta: z.string().optional().describe('AAAA-MM-DD')
  }
}, async ({ desde, hasta }) => texto(await api('listar_eventos', { desde, hasta })));

// Las tareas del profe (las del pósit de Notas y de la vista Hoy).
const CAMPOS_TAREA = {
  vence: z.string().optional().describe('Día en que vence, AAAA-MM-DD ("" la deja sin fecha)'),
  inicio: z.string().optional().describe('Desde cuándo se muestra, AAAA-MM-DD (por defecto, hoy)'),
  clases: z.array(z.string()).optional().describe('claseId de listar_clases ([] = ninguna)'),
  sesionId: z.string().optional().describe('Sesión, reunión o evento al que va ligada ("" = ninguno)')
};

server.registerTool('listar_tareas', {
  title: 'Listar tareas',
  description: 'Tareas del profesor (pendientes generales con vencimiento, clases y ' +
    'sesión o reunión opcionales). Úsalo antes de editar, para tener el tareaId. ' +
    'Si el texto sale como «cifrado», falta CIF_KEY en la API.',
  inputSchema: {
    desde: z.string().optional().describe('Vencen (o empiezan) desde este día, AAAA-MM-DD'),
    hasta: z.string().optional().describe('…hasta este día, AAAA-MM-DD'),
    claseId: z.string().optional().describe('Solo las de esta clase'),
    pendientes: z.boolean().optional().describe('true = solo las no hechas')
  }
}, async (filtro) => texto(await api('listar_tareas', filtro)));

server.registerTool('crear_tarea', {
  title: 'Crear una tarea',
  description: 'Apunta una tarea en las Tareas del profesor. Confirma antes el texto ' +
    'y la fecha con él: escribe en su cuaderno real.',
  inputSchema: { texto: z.string().describe('Qué hay que hacer (máx. 300 caracteres)'), ...CAMPOS_TAREA }
}, async (tarea) => texto(await api('crear_tarea', { tarea })));

server.registerTool('editar_tarea', {
  title: 'Editar una tarea',
  description: 'Cambia una tarea existente: texto, fechas, clases, sesión/reunión o si ' +
    'está hecha. Solo se tocan los campos que envíes. Borrar se hace desde la app.',
  inputSchema: {
    tareaId: z.string().describe('De listar_tareas'),
    texto: z.string().optional(),
    hecha: z.boolean().optional(),
    ...CAMPOS_TAREA
  }
}, async ({ tareaId, ...cambios }) => texto(await api('editar_tarea', { tareaId, cambios })));

server.registerTool('comprobar_conexion', {
  title: 'Comprobar la conexión',
  description: 'Verifica que el servidor llega a Evaluanda. Útil al configurarlo.',
  inputSchema: {}
}, async () => texto(await api('ping')));

await server.connect(new StdioServerTransport());
